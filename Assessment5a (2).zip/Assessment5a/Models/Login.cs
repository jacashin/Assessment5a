﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment5a.Models
{
    public class Login
    {
        public string Name { get; set; }

        public string Password { get; set; }
    }
}
