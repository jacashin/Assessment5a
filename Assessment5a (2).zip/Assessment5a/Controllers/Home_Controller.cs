﻿using Microsoft.AspNetCore.Mvc;

namespace Assessment5a.Controllers
{
    public class Home_Controller : Controller
    {

        public IActionResult Index()
        {
            return View("Home Page");
        }
        [HttpPost]
        public IActionResult Login(string Password, string Name)
        {
           
            if (Password != "open sesame")
            {
                RedirectToAction("WrongPassword");
            }
            return View("Welcome");
        }
        [HttpGet]
        public ActionResult Welcome(string Name, int LengthOf)
        {

            return View();
        }
   
        public IActionResult WrongPassword()
        {
            return View();
        }
    }
}